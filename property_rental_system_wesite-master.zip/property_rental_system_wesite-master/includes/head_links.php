<link rel="icon" href="img/common/jss_logo.jpg" type="image/X-UA-Compatible">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
            integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/header1.css">
    <link rel="stylesheet" href="css/loginmodal.css">
    <link rel="stylesheet" href="css/signupmodal.css">
    <link rel="stylesheet" href="css/Indexpropertylists.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/fontawesome_all.css">
    