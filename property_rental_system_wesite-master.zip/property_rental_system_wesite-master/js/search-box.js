function search() {
    var areaInput = document.getElementById("areaInput");
    var selectedArea = areaInput.value;

    alert("You selected", selectedArea);
}

