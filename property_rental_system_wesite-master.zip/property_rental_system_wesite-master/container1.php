<div class="properties_lists hs">
            <div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider1.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                    
                </div>
            </div>
            <div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider2.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <i class="fa-duotone fa-pipe"></i>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                </div>
            </div>
            <div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider3.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                </div>
            </div><div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider1.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                </div>
            </div>
            <div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider2.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                </div>
            </div>
            <div class="property_item">
                <div class="image"><a href="#"><img src="img/index/carousel/slider3.jpg" height="200px" width="300px"
                            alt=""></a></div>
                <div class="property_info_index">
                    <div class="addAndRate">
                        <div class="address">prakash nagar, latur</div>
                        <div class="rent">10000rs</div>
                    </div>
                    <div class="addAndRate">
                    <div class="bhk">2bhk</div>
                    <div class="bhk">ready to move</div>
                    </div>
                </div>
            </div>
        </div>